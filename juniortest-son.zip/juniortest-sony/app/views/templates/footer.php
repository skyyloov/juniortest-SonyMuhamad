
<footer class="footer mt-auto py-3">
    <div class="container">
        <span class="text-muted">ScandiWeb Test Assignment</span>
    </div>
</footer>
</body>

<script src="https://scmganding.site/juniortest-sony/js/jquery.js"></script>
<script src="https://scmganding.site/juniortest-sony/js/script.js"></script>
</html>